<?php
require('musisys.php');

$edicao = new EdicaoMusisys;
$edicao->EdicaoMusisys();

$artistas = $edicao->listarEdicaoPalcoArtista();

echo "<style>";
echo "body { font-family: 'Arial', sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; text-align: center; }";
echo "h2 { color: #333; margin-bottom: 20px; }";
echo ".container { display: flex; flex-wrap: wrap; justify-content: center; }";
echo ".card { flex: 1 1 calc(33.3333% - 20px); background-color: #fff; padding: 15px; margin: 10px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); transition: transform 0.3s ease-in-out; }";
echo ".card:hover { transform: scale(1.1); }";
echo "</style>";

echo "<div style='text-align: center; padding: 20px;'>";
echo "<h2>Lista de Edições, Palcos e Artistas</h2>";

if (!empty($artistas)) {
    echo "<div class='container'>";

    foreach ($artistas as $artista) {
        echo "<div class='card'>";
        echo "<strong>Edição:</strong> " . $artista['numero_edicao'] . "<br>";
        echo "<strong>Palco:</strong> " . $artista['codigo_palco'] . "<br>";
        echo "<strong>Artista:</strong> " . $artista['nome_artista'];
        echo "</div>";
    }

    echo "</div>";
} else {
    echo "<p style='color: #999;'>Nenhuma informação encontrada.</p>";
}

echo "<br><button style='background-color: #3498db; color: #fff; padding: 10px 20px; font-size: 1em; border: none; cursor: pointer; transition: background-color 0.3s, transform 0.3s;' onclick='window.location.href=\"menu.html\"'>Voltar ao Menu</button>";

echo "</div>";

$edicao->fecharBDMusisys();
?>
