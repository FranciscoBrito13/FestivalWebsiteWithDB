<?php
class Musisys {
    var $conn;

    function ligarBD() {
        $this->conn = mysqli_connect("localhost", "root", "");
        if (!$this->conn) {
            return -1;
        }

        mysqli_select_db($this->conn, "musisys");
    }	

    function executarSQL($sql_command) {
        $resultado = mysqli_query($this->conn, $sql_command);
        return $resultado;
    }

    function numero_linhas($tabela) {
        $linhas = 0;
        $rs = $this->executarSQL("SELECT * FROM $tabela");
        return mysqli_num_rows($rs);
    }

    function fecharBD() {
        mysqli_close($this->conn);
    }
}

class EdicaoMusisys extends Musisys {
    var $db_musisys;

    function EdicaoMusisys() {
        $this->db_musisys = new Musisys;
        $this->db_musisys->ligarBD();
    }

    function novaEdicao($numero, $nome, $localidade, $local, $data_inicio, $data_fim, $lotacao) {
        if ($numero != 0 && !empty($numero) && $numero != '') {
            $sql = "INSERT INTO edicao VALUES ('$numero', '$nome', '$localidade', '$local', '$data_inicio', '$data_fim', '$lotacao')";
            $this->db_musisys->executarSQL($sql);
        } else {
            return -1;
        }
    }

    function pesquisaBasica($numeroArtista){
        $artistas = array(); 
    
        if($numeroArtista != 0){
            $sql = "SELECT DISTINCT participante.nome
                    FROM participante, contrata
                    WHERE participante.codigo = contrata.Participante_codigo_
                    AND participante.codigo = $numeroArtista";
        } else{
            $sql = "SELECT DISTINCT participante.nome
            FROM participante, contrata
            WHERE participante.codigo = contrata.Participante_codigo_";
        }
        $result_set = $this->db_musisys->executarSQL($sql);
    
        while ($row = mysqli_fetch_array($result_set)) {
            $artistas[] = $row['nome'];
        }
    
        return $artistas; 
    }

    function pesquisaAvancada($idPalco, $numeroEntrevistas) {
        $artistas = array(); 
    
        $sql = "SELECT DISTINCT participante.nome
                FROM participante
                JOIN contrata ON participante.codigo = contrata.Participante_codigo_
                WHERE contrata.Palco_codigo = $idPalco
                  AND (
                    SELECT COUNT(*)
                    FROM entrevista
                    WHERE entrevista.Participante_codigo_ = participante.codigo
                  ) >= $numeroEntrevistas";
    
        $result_set = $this->db_musisys->executarSQL($sql);
    
        while ($row = mysqli_fetch_array($result_set)) {
            $artistas[] = $row['nome'];
        }
    
        return $artistas; 
    }
    function listarEdicaoPalcoArtista() {
        $infoEdicaoPalcoArtista = array(); 
    
        $sql = "SELECT edicao.numero AS numero_edicao, palco.codigo AS codigo_palco, participante.nome AS nome_artista
        FROM Edicao
        JOIN contrata ON edicao.numero = contrata.Edicao_numero_
        JOIN participante ON contrata.Participante_codigo_ = participante.codigo
        JOIN palco ON contrata.Palco_codigo = palco.codigo
        WHERE Edicao.data_inicio > CURDATE()
        GROUP BY edicao.numero, participante.nome";
    
        $result_set = $this->db_musisys->executarSQL($sql);
    
        while ($row = mysqli_fetch_assoc($result_set)) {
            $infoEdicaoPalcoArtista[] = array(
                'numero_edicao' => $row['numero_edicao'],
                'codigo_palco' => $row['codigo_palco'],
                'nome_artista' => $row['nome_artista']
            );
        }
    
        return $infoEdicaoPalcoArtista;
    }

    function removerArtistaEdicao($edicao, $codigo) {
        $sql = "SELECT * FROM Contrata WHERE Edicao_numero_ = $edicao AND Participante_codigo_ = $codigo";
        $sql2 = "DELETE FROM Contrata WHERE Edicao_numero_ = $edicao AND Participante_codigo_ = $codigo";

        $result_set = $this->db_musisys->executarSQL($sql);
    
        $row_count = mysqli_num_rows($result_set);
        if ($row_count == 0) {
            return -1;
        }
        
        $this->db_musisys->executarSQL($sql2);
    }

    function mudarArtistaPalco($edicao, $artista, $novoPalco){
        $sql = "SELECT * 
        FROM contrata
        JOIN edicao ON contrata.Edicao_numero_ = edicao.numero
        WHERE edicao.data_inicio > CURRENT_TIMESTAMP 
        AND contrata.Participante_codigo_ = $artista
        AND contrata.Edicao_numero_ = $edicao";
        $sql2 = "UPDATE contrata
        SET Palco_codigo = $novoPalco
        WHERE contrata.Edicao_numero_ = $edicao
        AND contrata.Participante_codigo_ = $artista";

        
        $result_set = $this->db_musisys->executarSQL($sql); 

        $row_count = mysqli_num_rows($result_set);
        if ($row_count == 0) {
            return -1;
        }

        $this->db_musisys->executarSQL($sql2);

    }


    function fecharBDMusisys() {
        $this->db_musisys->fecharBD();
    }
}

?>