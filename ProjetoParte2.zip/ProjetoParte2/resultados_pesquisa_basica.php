<?php
if (isset($_POST["codigo_participante"])) {
    $codigo_participante = $_POST["codigo_participante"];

    require('musisys.php');

    $edicao = new EdicaoMusisys;
    $edicao->EdicaoMusisys();

    $artistas = $edicao->pesquisaBasica($codigo_participante);

    echo "<div style='text-align: center; padding: 20px;'>";

    if (!empty($artistas)) {
        if ($codigo_participante != 0) {
            echo "<h2>Artista com o código $codigo_participante</h2>";
            echo "<ul style='list-style-type: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; justify-content: center;'>";

            foreach ($artistas as $artista) {
                echo "<li style='background-color: #fff; padding: 15px; margin: 10px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);'>$artista</li>";
            }

            echo "</ul>";
        } else {
            echo "<h2>Todos os artistas que já atuaram:</h2>";
            echo "<ul style='list-style-type: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; justify-content: center;'>";

            foreach ($artistas as $artista) {
                echo "<li style='background-color: #fff; padding: 15px; margin: 10px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);'>$artista</li>";
            }

            echo "</ul>";
        }
    } else {
        echo "<p style='color: #999;'>Nenhum artista encontrado para o código de participante $codigo_participante, ou é um artista não registrado, ou nunca atuou numa edição</p>";
    }

    echo "<br><button style='background-color: #3498db; color: #fff; padding: 10px 20px; font-size: 1em; border: none; cursor: pointer; transition: background-color 0.3s, transform 0.3s;' onclick='window.location.href=\"menu.html\"'>Voltar ao Menu</button>";

    echo "</div>";

    $edicao->fecharBDMusisys();
}
?>
