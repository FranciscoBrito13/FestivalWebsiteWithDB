<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mudar Artista de Palco - Resultado</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            flex-direction: column;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        p {
            color: #333;
            margin-bottom: 30px;
        }

        button {
            background-color: #3498db;
            color: #fff;
            padding: 10px 20px;
            font-size: 1em;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }

        button:hover {
            background-color: #2980b9;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <h2>Mudar Artista de Palco - Resultado</h2>

    <?php
    require('musisys.php');

    $edicaoNumero = $_POST['numero'];
    $artistaNumero = $_POST['artista'];
    $novoPalco = $_POST['palco'];

    $edicao = new EdicaoMusisys;
    $edicao->EdicaoMusisys();

    $resultado = $edicao->mudarArtistaPalco($edicaoNumero, $artistaNumero, $novoPalco);

    
    
    if ($resultado == -1) {
        echo "<p>Erro: Artista ou Edição não existe.</p>";
    } else {
        echo "<p>Artista mudado de palco com sucesso!</p>";
    }

    $edicao->fecharBDMusisys();
    ?>

    <button onclick="window.location.href='menu.html'">Voltar ao Menu</button>
</body>
</html>
