<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BD Musisys - Introduzir</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        a {
            color: #3498db;
            text-decoration: none;
            transition: color 0.3s;
        }

        a:hover {
            color: #2980b9;
        }
    </style>
</head>
<body>

    <h1>Valor Introduzido!</h1><br>

    <?php
    require('musisys.php');

    $edicao = new EdicaoMusisys;
    $edicao->EdicaoMusisys();
    $edicao->novaEdicao($_POST["numero"], $_POST["nome"], $_POST["localidade"], $_POST["local"], $_POST["data_inicio"], $_POST["data_fim"], $_POST["lotacao"]);
    $edicao->fecharBDMusisys();
    ?>

    <br>
    <a href="menu.html">Voltar ao menu</a>
</body>
</html>
