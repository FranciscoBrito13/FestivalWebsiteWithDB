<?php
$edicaoNumero = $_POST["edicao_numero"];
$artistaNumero = $_POST["id_artista"];

require('musisys.php');

$edicao = new EdicaoMusisys;
$edicao->EdicaoMusisys();

$result = $edicao->removerArtistaEdicao($edicaoNumero, $artistaNumero);

$edicao->fecharBDMusisys();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remover Artista - Resultado</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            flex-direction: column;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        p {
            color: #333;
            margin-bottom: 30px;
        }

        .warning {
            color: #808080; /* Soft gray color */
            font-weight: bold;
            margin-bottom: 20px;
        }

        button {
            background-color: #3498db;
            color: #fff;
            padding: 10px 20px;
            font-size: 1em;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }

        button:hover {
            background-color: #2980b9;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <?php if ($result == -1) : ?>
        <p class="warning">Nenhum artista encontrado para a edição <?php echo $edicaoNumero; ?> e código <?php echo $artistaNumero; ?></p>
    <?php else : ?>
        <h2>Artista removido com sucesso!</h2>
        <p>Edição: <?php echo $edicaoNumero; ?>, Artista: <?php echo $artistaNumero; ?></p>
    <?php endif; ?>
    
    <button onclick="window.location.href='menu.html'">Voltar ao Menu</button>
</body>
</html>
